﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows.Forms;
using System.Drawing;
using LibreHardwareMonitor.Hardware;

namespace TempWidget
{
    public partial class MainWindow : Window
    {
        private void Window_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
                this.DragMove();
        }
        private Computer computer;
        private NotifyIcon trayIcon;

        public MainWindow()
        {
            InitializeComponent();

            computer = new Computer
            {
                IsCpuEnabled = true,
                IsGpuEnabled = true
            };
            computer.Open();

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(2);
            timer.Tick += UpdateTemperature;
            timer.Start();

            // Иконка в трее
            trayIcon = new NotifyIcon();
            trayIcon.Icon = SystemIcons.Application;
            trayIcon.Visible = true;
            trayIcon.Text = "TempWidget";

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add("Показать", null, (s, e) => this.Show());
            menu.Items.Add("Выход", null, (s, e) => System.Windows.Application.Current.Shutdown());

            trayIcon.ContextMenuStrip = menu;
        }

        private void UpdateTemperature(object sender, EventArgs e)
        {
            float? cpuTemp = GetCpuTemperature();
            float? gpuTemp = GetGpuTemperature();

            CpuTempText.Text = cpuTemp.HasValue ? $"CPU: {cpuTemp.Value:F0} °C" : "CPU: N/A";
            GpuTempText.Text = gpuTemp.HasValue ? $"GPU: {gpuTemp.Value:F0} °C" : "GPU: N/A";
        }

        private float? GetCpuTemperature()
        {
            foreach (var hardwareItem in computer.Hardware)
            {
                if (hardwareItem.HardwareType == HardwareType.Cpu)
                {
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Temperature &&
                            sensor.Name.Contains("Core Max") &&
                            sensor.Value.HasValue)
                        {
                            return sensor.Value;
                        }
                    }
                }
            }
            return null;
        }

        private float? GetGpuTemperature()
        {
            foreach (var hardwareItem in computer.Hardware)
            {
                if (hardwareItem.HardwareType == HardwareType.GpuNvidia ||
                    hardwareItem.HardwareType == HardwareType.GpuAmd ||
                    hardwareItem.HardwareType == HardwareType.GpuIntel)
                {
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Temperature &&
                            sensor.Name.Contains("GPU Core") &&
                            sensor.Value.HasValue)
                        {
                            return sensor.Value;
                        }
                    }
                }
            }
            return null;
        }

        private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double percent = e.NewValue;
            this.Opacity = percent / 100.0;

            if (OpacityLabel != null)
                OpacityLabel.Text = $"{(int)percent}%";
        }

        private void TopmostCheckbox_Checked(object sender, RoutedEventArgs e)
        {
            this.Topmost = true;
        }

        private void TopmostCheckbox_Unchecked(object sender, RoutedEventArgs e)
        {
            this.Topmost = false;
        }

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            SettingsPanel.Visibility = SettingsPanel.Visibility == Visibility.Visible
                ? Visibility.Collapsed
                : Visibility.Visible;
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }


        private void Window_RightClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ChangedButton == System.Windows.Input.MouseButton.Right)
            {
                ContextMenu contextMenu = new ContextMenu();

                // Показать/Скрыть настройки
                MenuItem toggleSettings = new MenuItem
                {
                    Header = SettingsPanel.Visibility == Visibility.Visible ? "Скрыть настройки" : "Показать настройки"
                };
                toggleSettings.Click += (s, args) =>
                {
                    SettingsPanel.Visibility = SettingsPanel.Visibility == Visibility.Visible
                        ? Visibility.Collapsed
                        : Visibility.Visible;
                };

                // Скрыть окно
                MenuItem hideItem = new MenuItem { Header = "Скрыть окно" };
                hideItem.Click += (s, args) =>
                {
                    this.Hide();
                };

                // Выйти
                MenuItem exitItem = new MenuItem { Header = "Выход" };
                exitItem.Click += (s, args) =>
                {
                    System.Windows.Application.Current.Shutdown();
                };

                // Добавим всё в меню
                contextMenu.Items.Add(toggleSettings);
                contextMenu.Items.Add(hideItem);
                contextMenu.Items.Add(new Separator());
                contextMenu.Items.Add(exitItem);

                // Показать меню
                contextMenu.IsOpen = true;
            }
        }
    }
}